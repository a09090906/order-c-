﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace classnew
{
    public partial class Form2 : Form
    {

        public RadioButton ice1 = new RadioButton();     //飲料 冰/糖
        public RadioButton ice2 = new RadioButton();
        public RadioButton ice3 = new RadioButton();
        public RadioButton suger1 = new RadioButton();
        public RadioButton suger2 = new RadioButton();
        public RadioButton suger3 = new RadioButton();
        public RadioButton suger4 = new RadioButton();

        public List<p> myStringLists = new List<p>();  //所有菜單
        public List<p> melist = new List<p>(); //選定的菜單
        public List<pcs> pcslist = new List<pcs>(); //選定的菜單
        public Form2()  //載入菜單 
        {
            InitializeComponent();
            Class1 g = new Class1();
            DataSet ds1 = g.sqltable("本週店家");
            string shop = ds1.Tables[0].Rows[0].ItemArray[0].ToString();
            label5.Text = shop;
            DataSet ds = g.sqladd(shop);
            int tablecount = ds.Tables[0].Rows.Count;
            for (int i = 0; i <= tablecount - 1; i++)
            {
                string food = ds.Tables[0].Rows[i].ItemArray[0].ToString();
                int price = int.Parse(ds.Tables[0].Rows[i].ItemArray[1].ToString());

                myStringLists.Add(new p(food, price));
            }
     
            for (int i = 0; i <= tablecount - 1; i++)
            {
                string food = ds.Tables[0].Rows[i].ItemArray[0].ToString();
                int price = int.Parse(ds.Tables[0].Rows[i].ItemArray[1].ToString());
                string sp = ds.Tables[0].Rows[i].ItemArray[2].ToString();

                pcslist.Add(new pcs(food, price, sp));
            }

            listBox2.DisplayMember = "Display";

            listBox2.ValueMember = "price";

            for (int i = 0; i <= tablecount - 1; i++)
            {
                listBox2.Items.Add(new pcs(pcslist[i].food, pcslist[i].price, ""));

            }
            string[] fp = new string[6];
            fp[0] = "顯示全部";
            fp[1] = "麵";
            fp[2] = "飯";
            fp[3] = "其他";
            fp[4] = "飲料";
            fp[5] = "水餃";
            for (int i = 0; i <= 5; i++)
            {
                listBox1.Items.Insert(i, fp[i]);
            }

        }

        private void button3_Click(object sender, EventArgs e)//取消訂單
        {
            Class1 b = new Class1();
            b.sqldet(name.Text);
            DataSet ds = b.select(name.Text);
            this.dataGridView1.DataSource = ds.Tables[0].DefaultView;
            MessageBox.Show("已取消" + name.Text.Trim() + "的所有訂餐");

            return;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.GetSelected(0))
            {
                try
                {
                    foodlb.Text = "";
                    foodlb.Text = "加大或加辣等請於備註輸入";
                    flowLayoutPanel2.Controls.Clear();
                    flowLayoutPanel3.Controls.Clear();
                    listBox2.Items.Clear();
                    pcslist.Clear();
                    Class1 g = new Class1();
                    DataSet ds1 = g.sqltable("本週店家");
                    string shop = ds1.Tables[0].Rows[0].ItemArray[0].ToString();
                    DataSet ds = g.sqladd(shop);
                    int tablecount = ds.Tables[0].Rows.Count;
                    for (int i = 0; i <= tablecount - 1; i++)
                    {
                        string food = ds.Tables[0].Rows[i].ItemArray[0].ToString();
                        int price = int.Parse(ds.Tables[0].Rows[i].ItemArray[1].ToString());
                        string sp = ds.Tables[0].Rows[i].ItemArray[2].ToString();

                        pcslist.Add(new pcs(food, price, sp));
                    }
                    listBox2.DisplayMember = "Display";

                    listBox2.ValueMember = "price";

                    for (int i = 0; i <= tablecount - 1; i++)
                    {
                        listBox2.Items.Add(new pcs(pcslist[i].food, pcslist[i].price, ""));

                    }
                    textBox1.Text = "";
                    ndp.Visible = false;
                    dup.Text = "";
                }
                catch (Exception)
                {
                    MessageBox.Show("請選擇食物");
                }


            }

            if (listBox1.GetSelected(1))
            {
                listboxadd("麵");
                flowLayoutPanel2.Controls.Clear();
                flowLayoutPanel3.Controls.Clear();
                foodlb.Text = "";
                foodlb.Text = "加麵或加辣等請於備註輸入";
                textBox1.Text = "";
                ndp.Visible = false;
                dup.Text = "";
            }
            if (listBox1.GetSelected(2))
            {
                textBox1.Text = "";
                listboxadd("飯");
                flowLayoutPanel2.Controls.Clear();
                flowLayoutPanel3.Controls.Clear();
                foodlb.Text = "";
                foodlb.Text = "加飯或少飯或加辣等請於備註輸入";
                ndp.Visible = false;
                dup.Text = "";
            }
            if (listBox1.GetSelected(3))
            {
                textBox1.Text = "";
                listboxadd("其他");
                flowLayoutPanel2.Controls.Clear();
                flowLayoutPanel3.Controls.Clear();
                foodlb.Text = "";
                foodlb.Text = "加大或加辣等請於備註輸入";
                ndp.Visible = false;
                dup.Text = "";
            }


            if (listBox1.GetSelected(5))
            {
                foodlb.Text = "";
                listboxadd("水餃");
                flowLayoutPanel2.Controls.Clear();
                flowLayoutPanel3.Controls.Clear();
                ndp.Visible = true;
                dup.Text = "請輸入水餃數量";               
                
            }
            if (listBox1.GetSelected(4)) //飲料
            {
                ndp.Visible = false;
                dup.Text = "";
                flowLayoutPanel2.Controls.Clear();
                flowLayoutPanel3.Controls.Clear();
                foodlb.Text = "";
                listboxadd("飲料");
                //flowLayoutPanel2.Controls.Clear();
                flowLayoutPanel3.Controls.Clear();
                ice1.Parent = flowLayoutPanel2;
                ice1.Text = "正常";
                ice1.Name = "ice1";
                ice2.Parent = flowLayoutPanel2;
                ice2.Text = "少冰";
                ice2.Name = "ice2";
                ice3.Parent = flowLayoutPanel2;
                ice3.Text = "去冰";
                ice3.Name = "ice3";
                suger1.Parent = flowLayoutPanel3;
                suger1.Text = "正常";
                suger1.Name = "suger1";
                suger2.Parent = flowLayoutPanel3;
                suger2.Text = "半糖";
                suger2.Name = "suger2";
                suger3.Parent = flowLayoutPanel3;
                suger3.Text = "微糖";
                suger3.Name = "suger3";
                suger4.Parent = flowLayoutPanel3;
                suger4.Text = "無糖";
                suger4.Name = "suger4";
            }
            string icestr = "";
            string sugerstr = "";
            if (ice1.Checked)
            {
                icestr = "";
                icestr = "正常";
            }
            if (ice2.Checked)
            {
                icestr = "";
                icestr = "少冰";
            }
            if (ice3.Checked)
            {
                icestr = "";
                icestr = "去冰";
            }
            if (suger1.Checked)
            {
                sugerstr = "";
                sugerstr = "正常";
            }
            if (suger2.Checked)
            {
                sugerstr = "";
                sugerstr = "半糖";
            }
            if (suger3.Checked)
            {
                sugerstr = "";
                sugerstr = "微糖";
            }
            if (suger4.Checked)
            {
                sugerstr = "";
                sugerstr = "無糖";
            }
            textBox1.Text = sugerstr + icestr;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //string Food = listBox2.SelectedItem.ToString().Split(',')[0];
            //string price = listBox2.SelectedItem.ToString().Split(',')[1].Replace("元", "");
            try
            {
              if (listBox1.GetSelected(5))
                {
                    order(name.Text, (listBox2.SelectedItem as pcs).food+ndp.Value+"顆", ((listBox2.SelectedItem as pcs).price*ndp.Value).ToString(), textBox1.Text);
                }
                else
                {
                    order(name.Text, (listBox2.SelectedItem as pcs).food, (listBox2.SelectedItem as pcs).price.ToString(), textBox1.Text);
                }
               
            }
            catch (Exception )
            {
                MessageBox.Show("請選擇食物");
            }
            
        }

        public void order(string name, string food, string price, string remark)
        {
            try
            {
                Class1 g = new Class1();
                g.sqladd(name, food, price, remark);
                DataSet ds = g.select(this.name.Text);
                this.dataGridView1.DataSource = ds.Tables[0].DefaultView;
            }
            catch (Exception )
            {
                MessageBox.Show("請選擇食物");
            }

        }


        public void listboxadd(string foodlist)
        {
            try
            {
                listBox2.Items.Clear();
                pcslist.Clear();
                Class1 g = new Class1();
                DataSet ds1 = g.sqltable("本週店家");
                string shop = ds1.Tables[0].Rows[0].ItemArray[0].ToString();
                DataSet ds2 = g.sp(shop, foodlist);
                int tablecount = ds2.Tables[0].Rows.Count;
                for (int i = 0; i <= tablecount - 1; i++)
                {
                    string food = ds2.Tables[0].Rows[i].ItemArray[0].ToString().Trim();
                    int price = int.Parse(ds2.Tables[0].Rows[i].ItemArray[1].ToString());
                    string sp = ds2.Tables[0].Rows[i].ItemArray[2].ToString();

                    pcslist.Add(new pcs(food, price, sp));
                }
                listBox2.DisplayMember = "Display";

                listBox2.ValueMember = "price";

                for (int i = 0; i <= tablecount - 1; i++)
                {
                    listBox2.Items.Add(new pcs(pcslist[i].food, pcslist[i].price, ""));

                }
            }
            catch (Exception )
            {
                MessageBox.Show("請選擇食物");
            }

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((string)listBox1.SelectedItem == "飯")
                MessageBox.Show((string)listBox1.SelectedItem);
        }
    }
}
