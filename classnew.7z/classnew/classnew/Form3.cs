﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Printing;

namespace classnew
{



    public partial class Form3 : Form
    {
        public List<string> mylist = new List<string>();
        public List<newp> eatlist = new List<newp>();
        public List<p> foodlist = new List<p>();
        public List<p> peplist = new List<p>();
        Class1 form3Class = new Class1();
       


        public Form3()
        {
            InitializeComponent();
            Class1 a = new Class1();           
            DataSet ds = a.sqltable("店家名稱");
            int dscount = ds.Tables[0].Rows.Count;
            string[] shopname = new string[dscount];
            for(int i = 0; i <= dscount - 1; i++)
            {
                shopname[0] = ds.Tables[0].Rows[i].ItemArray[0].ToString();
                listBox1.Items.Add(shopname[0]);
            }
            DataSet ds1 = a.sqladd("訂餐");
            DataSet ds2 = a.sqltable("訂餐");

            DataSet dsman = a.groby(); // 印出每人應繳費用
            int dsmancount = dsman.Tables[0].Rows.Count;
            for (int i = 0;i <= dsmancount - 1; i++) 
            {              
                string name = dsman.Tables[0].Rows[i].ItemArray[0].ToString();
                int money = int.Parse(dsman.Tables[0].Rows[i].ItemArray[1].ToString());
                peplist.Add(new p(name, money));
            }

            foreach(p i in peplist)
            {
                Label h = new Label();
                h.Parent = flowLayoutPanel2;
                h.Text = i.price+"元,for"+i.food;
            }
            int ds2count = ds2.Tables[0].Rows.Count; //各餐點數量

            for(int i = 0; i <= ds2count - 1; i++)
            {
                string namep = ds2.Tables[0].Rows[i].ItemArray[0].ToString();
                string foodp = ds2.Tables[0].Rows[i].ItemArray[1].ToString();
                int pricep = int.Parse(ds2.Tables[0].Rows[i].ItemArray[2].ToString());
                eatlist.Add(new newp(namep, foodp, pricep));
            }
            int j = 0;
            for(int i =0; i <= ds2count - 1; i++)
            {
                j=j+eatlist[i].price;
            }
            allcash.Text = j.ToString(); // 計算總價格            
            this.dataGridView2.DataSource = ds1.Tables[0].DefaultView; //印出點餐

            button("刪除");
            button("編輯");


            today();
            foreach(p i in foodlist)
            {
                Label e = new Label();
                e.Parent = flowLayoutPanel1;
                e.Text = i.price+"份"+i.food;
            }
            string[] fp = new string[5];           
            fp[0] = "麵";
            fp[1] = "飯";
            fp[2] = "其他";
            fp[3] = "飲料";
            fp[4] = "水餃";
            for (int i = 0; i <= 4; i++)
            {
                listBox2.Items.Add(fp[i]);
            }
            
        }




        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Class1 a = new Class1();
                a.shopadd(listBox1.SelectedItem.ToString(), food.Text, price.Text, listBox2.SelectedItem.ToString());
                DataSet ds = a.sqladd(listBox1.SelectedItem.ToString());//測試資料是否新增
                this.dataGridView1.DataSource = ds.Tables[0].DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                Class1 a = new Class1();
                a.foodshopadd(shop.Text);
                DataSet ds = a.sqltable("店家名稱");
                int dscount = ds.Tables[0].Rows.Count;
                string[] shopname = new string[dscount];
                for (int i = 0; i <= dscount - 1; i++)
                {
                    shopname[i] = "";
                }
                listBox1.Items.Clear();
                for (int i = 0; i <= dscount - 1; i++)
                {
                    shopname[0] = ds.Tables[0].Rows[i].ItemArray[0].ToString();
                    listBox1.Items.Add(shopname[0]);
                }
                MessageBox.Show("已經新增" + shop.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Class1 a = new Class1();
                a.foodshopdelete(shop.Text);
                DataSet ds = a.sqltable("店家名稱");
                int dscount = ds.Tables[0].Rows.Count;
                string[] shopname = new string[dscount];
                for (int i = 0; i <= dscount - 1; i++)
                {
                    shopname[i] = "";
                }
                listBox1.Items.Clear();
                for (int i = 0; i <= dscount - 1; i++)
                {
                    shopname[0] = ds.Tables[0].Rows[i].ItemArray[0].ToString();
                    listBox1.Items.Add(shopname[0]);
                }
                MessageBox.Show("已經刪除該店家");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e) //刪除餐點
        {
            try
            {
                Class1 a = new Class1();
                a.fooddelete(listBox1.SelectedItem.ToString(), food.Text);
                DataSet ds = a.sqladd(listBox1.SelectedItem.ToString());//測試資料是否刪除
                this.dataGridView1.DataSource = ds.Tables[0].DefaultView;

                MessageBox.Show("已刪除該餐點");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                Class1 a = new Class1();
                a.deleteform();
                DataSet ds = a.sqladd("訂餐");               
                this.dataGridView2.DataSource = ds.Tables[0].DefaultView;
                flowLayoutPanel1.Controls.Clear();
                flowLayoutPanel2.Controls.Clear();
                foodlist.Clear();
                peplist.Clear();
                allcash.Text = "";
                a.todayeat(listBox1.SelectedItem.ToString());
                today();
                foreach (p i in foodlist)
                {
                    Label r = new Label();
                    r.Parent = flowLayoutPanel1;
                    r.Text = i.price + "份" + i.food;
                }               
                MessageBox.Show("今天決定吃" + listBox1.SelectedItem.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }         
        }

        public void today()  
        {
            Class1 a = new Class1();
            DataSet dds = a.sqltable("本週店家");   //取出今日店家
            string todayshop = dds.Tables[0].Rows[0].ItemArray[0].ToString();
            DataSet ds3 = a.sqltable(todayshop);
            int ds3count = ds3.Tables[0].Rows.Count;          
            for (int i = 0; i <= ds3count - 1; i++) //將該店家餐點列出
            {
                string fdcot = ds3.Tables[0].Rows[i].ItemArray[0].ToString();
                DataSet dsfood = a.foodcount(ds3.Tables[0].Rows[i].ItemArray[0].ToString());
                int foodcot = int.Parse(dsfood.Tables[0].Rows[0].ItemArray[0].ToString());
                foodlist.Add(new p(fdcot, foodcot));
            }           
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
        Bitmap bmp;
        private void button6_Click(object sender, EventArgs e)
        {
            int dgvhigh = dataGridView2.Height;
            dataGridView2.Height = dataGridView2.RowCount * dataGridView2.RowTemplate.Height * 2;
            bmp = new Bitmap(dataGridView2.Width, dataGridView2.Height);
            dataGridView2.DrawToBitmap(bmp, new Rectangle(0, 0, dataGridView2.Width, dataGridView2.Height));
            dataGridView2.Height = dgvhigh;
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, PrintPageEventArgs e)
        {
            e.Graphics.DrawImage(bmp, 0, 0);
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)

        {
            

            if (e.ColumnIndex == 0)
            {
                //get the value which you want to display
               // String customer = dataGridView2.Rows[e.RowIndex].Cells[5].Value.ToString();
                Class1 a = new Class1();
                a.det((int) dataGridView2.Rows[e.RowIndex].Cells[6].Value);
                DataSet ds1 = a.sqladd("訂餐");
                this.dataGridView2.DataSource = ds1.Tables[0].DefaultView;
            }
            if (e.ColumnIndex == 1)
            {
                MessageBox.Show(e.RowIndex.ToString());
                dataGridView2.Rows[e.RowIndex].Cells[5].ReadOnly = true;
              
            }
           

        }
        public void button (string buttonname) 
        {
            DataGridViewButtonColumn column3 = new DataGridViewButtonColumn();
            column3.Name = " ";
            column3.UseColumnTextForButtonValue = true;
            column3.Text = buttonname;
            column3.Width = 30;
            dataGridView2.Columns.Add(column3);
        }
    }
   
}


