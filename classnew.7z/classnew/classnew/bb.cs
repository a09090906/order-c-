﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace classnew
{
    public class bb
    {
        public string food { get; set; }
        public int price { get; set; }
        public bb (string foodname,int pricename)
        {
            food = foodname;
            price = pricename;
        }
    }
}
