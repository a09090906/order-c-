﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classnew
{
    public class newp
    {
        public string name { set; get; }
        public string food { set; get; }
        public int price { set; get; }
        
        public newp(string name1,string food1, int price1)
        {
            name = name1;
            food = food1;
            price = price1;
        }
    }
}
