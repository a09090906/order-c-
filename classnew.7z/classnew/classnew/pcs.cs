﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classnew
{
    public class pcs
    {
        public string Display
        {
            get
            {
                return food+ price+"元";
            }
            set { }
        }
        public string food { set; get; }
        public int price { set; get; }
        public string add { set; get; }
        public pcs(string food1, int price1, string add1)
        {
            food = food1;
            price = price1;
            add = add1;
        }
    }
}
