﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace classnew
{
    class menu
    {
        public string weekfood()
        {
            string food1 = "";
            DateTime today = DateTime.Now;
            if (today.DayOfWeek == DayOfWeek.Monday)
            {
                food1 = "麥當勞";
            }
            else if (today.DayOfWeek == DayOfWeek.Tuesday)
            {
                food1 = "大內牛肉麵";
            }
            else if (today.DayOfWeek == DayOfWeek.Wednesday)
            {
                food1 = "東家便當";
            }
            else if (today.DayOfWeek == DayOfWeek.Thursday)
            {
                food1 = "東家便當";
            }
            else if (today.DayOfWeek == DayOfWeek.Friday)
            {
                food1 = "麥當勞";
            }
            return food1;
        }
        }
}
