﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace classnew
{
    public partial class Form1 : Form
    {
        string password = "";
        public Form1()
        {
            InitializeComponent();
            Class1 a = new Class1();
            DataSet ds = a.sqltable("帳號密碼");
         
            int tball = ds.Tables[0].Rows.Count;
            string[] name = new string[tball];
           
            for (int i = 0; i <= tball - 1; i++)
            {
                name[0] = ds.Tables[0].Rows[i].ItemArray[0].ToString().Trim();
               listBox1.Items.Add(name[0]);
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            Class1 a = new Class1();
           
            DataSet datap = a.pass2(listBox1.SelectedItem.ToString());
            password = datap.Tables[0].Rows[0].ItemArray[1].ToString().Trim();           
            string name=datap.Tables[0].Rows[0].ItemArray[0].ToString().Trim();
            Form3 newform3 = new Form3();
            if (listBox1.SelectedItem.ToString()=="冠麟")
            {
                if(textBox1.Text == password)
                {
                    newform3.ShowDialog();
                }
                else
                {
                    MessageBox.Show("密碼錯誤");
                    return;
                }
            }

            else if(textBox1.Text == password & listBox1.SelectedItem.ToString() == name)
            {
                Form2 newform2 = new Form2();
                newform2.name.Text = listBox1.SelectedItem.ToString();
                if (newform2.ShowDialog(this) == DialogResult.OK)
                {
                }
            }
            else
            {
                MessageBox.Show("密碼錯誤");
                return;
            }

        }


    }
}
