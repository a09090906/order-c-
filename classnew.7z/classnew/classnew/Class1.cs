﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace classnew
{
    class Class1
    {
        // public string Constr2 = "Data Source=LIUKUANLIN-PC\\SQLEXPRESS;Initial Catalog=DB2;Integrated Security=SSPI;";
        public string Constr = "Data Source=192.168.1.49;Initial Catalog=DB2;User ID=lunch;Password=lunch;";
        SqlConnection conn;
        public Class1()
        {
            conn = new SqlConnection(Constr);


        }



        public DataSet sqladd(string foodshop)
        {
            string Sqlstr = "select * from "+foodshop;
           // conn = new SqlConnection(Constr);
            SqlDataAdapter da = new SqlDataAdapter(Sqlstr, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
        public DataSet sqltable(string foodtable)
        {
            string sqlstr = "select * from " + foodtable;
            //conn = new SqlConnection(Constr);
            SqlDataAdapter da = new SqlDataAdapter(sqlstr, conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "datatable");
            DataTable dta = ds.Tables["datatable"];
            return ds;
        }
        public void sqladd(string name, string food,string money,string remarks)
        {
            conn = new SqlConnection(Constr);
            conn.Open();
            SqlCommand insterfood = new SqlCommand(@"INSERT INTO 訂餐 VALUES ('"+name+"','"+food+"','"+money+"','"+remarks+"')", conn);
            insterfood.ExecuteNonQuery();
        }
         public  void sqldet(string name)
        {
            conn = new SqlConnection(Constr);
            conn.Open();
            SqlCommand delfood = new SqlCommand(@"DELETE FROM 訂餐 WHERE 姓名='"+name+"'", conn);     
            delfood.ExecuteNonQuery();
        }
        public void todayeat(string shop)
        {
            conn = new SqlConnection(Constr);
            conn.Open();
            SqlCommand instfood2= new SqlCommand(@"DELETE FROM 本週店家", conn);
            instfood2.ExecuteNonQuery();
            SqlCommand instfood = new SqlCommand(@"INSERT INTO 本週店家 VALUES('" + shop + "')", conn);
            instfood.ExecuteNonQuery();
        }



        public void shopadd(string shop,string food,string money,string speice)
        {
            conn = new SqlConnection(Constr);
            conn.Open();
            SqlCommand instfood = new SqlCommand(@"INSERT INTO "+shop+" VALUES('"+food+"',"+money+",'"+speice+"',null)", conn);
            instfood.ExecuteNonQuery();
        }  
        public void foodshopadd(string shop)
        {
            try
            {
                conn = new SqlConnection(Constr);
                conn.Open();
                SqlCommand inster = new SqlCommand(@"INSERT INTO 店家名稱 VALUES('" + shop + "')", conn);
                SqlCommand inster2 = new SqlCommand(@"CREATE TABLE " + shop + "(餐點 char(10),價格 int,種類 char(10),備註 char(10))", conn);
                inster.ExecuteNonQuery();
                inster2.ExecuteNonQuery();
            }
        
          catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void foodshopdelete(string shop)
        {
            try
            {
                conn = new SqlConnection(Constr);
                conn.Open();
                SqlCommand deleteshop = new SqlCommand(@"delete from 店家名稱 where 店名='" + shop + "'", conn);
                SqlCommand deleteshop1 = new SqlCommand(@"DROP TABLE " + shop, conn);
                deleteshop.ExecuteNonQuery();
                deleteshop1.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
         public void fooddelete(string shop,string food)
        {
            conn = new SqlConnection(Constr);
            conn.Open();
            SqlCommand deletefood = new SqlCommand(@"delete from "+shop+" where 餐點='" + food + "'", conn);
            deletefood.ExecuteNonQuery();
        }
       
        public DataSet foodcount(string food)
        {

                string foodcon = "SELECT COUNT (餐點) FROM 訂餐 WHERE 餐點='"+ food +"'";
                conn = new SqlConnection(Constr);
                SqlDataAdapter da = new SqlDataAdapter(foodcon, conn);
                DataSet ds = new DataSet();
              da.Fill(ds, "datatable");
                DataTable dta = ds.Tables["datatable"];
                return ds;

        }
        public void deleteform()
        {
            conn = new SqlConnection(Constr);
            conn.Open();
            SqlCommand delfood = new SqlCommand(@"DELETE FROM 訂餐 ", conn);
            delfood.ExecuteNonQuery();
        }

        public DataSet groby()
        {

            string pep = "SELECT 姓名, SUM(價格) FROM 訂餐 GROUP BY 姓名;";
            conn = new SqlConnection(Constr);
            SqlDataAdapter da = new SqlDataAdapter(pep, conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "data");
            DataTable dta = ds.Tables["data"];
            return ds;           
        }

        public DataSet pass(string name)
        {
            string sqlstr = "select 密碼 from 帳號密碼 where" + name;
            conn = new SqlConnection(Constr);
            SqlDataAdapter da = new SqlDataAdapter(sqlstr, conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "datatable");
            DataTable dta = ds.Tables["datatable"];
            return ds;
        }
        public DataSet pass2(string name)
        {
            string sqlstr = "select * from 帳號密碼 where 姓名='"+ name+"'";
            conn = new SqlConnection(Constr);
            SqlDataAdapter da = new SqlDataAdapter(sqlstr, conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "datatable");
            DataTable dta = ds.Tables["datatable"];
            return ds;
        }

        public DataSet sp(string shop,string sp)
        {
            string sqlstr = "select * from "+shop+" where 種類='"+ sp+"'";
            conn = new SqlConnection(Constr);
            SqlDataAdapter da = new SqlDataAdapter(sqlstr, conn);
            DataSet ds = new DataSet();
            da.Fill(ds, "datatable");
            DataTable dta = ds.Tables["datatable"];
            return ds;
        }
        public DataSet select(string man)
        {
            string Sqlstr = "select * from 訂餐 where 姓名='"+man+"'";
            conn = new SqlConnection(Constr);
            SqlDataAdapter da = new SqlDataAdapter(Sqlstr, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;
        }
        public void det(int name)
        {
            conn = new SqlConnection(Constr);
            conn.Open();
            SqlCommand delfood = new SqlCommand(@"DELETE FROM 訂餐 WHERE id=" + name.ToString(), conn);
            delfood.ExecuteNonQuery();
        }


    }
}
